package com.example.na15;

import android.os.Bundle;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
	//GameView p;
	
	MySQLiteHelper helper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    	requestWindowFeature(Window.FEATURE_NO_TITLE);
    	setContentView(new GameView(this));
    	
    	//helper = new MySQLiteHelper(MainActivity.this,"MYDATABASE.db");
        
    	//String userName = rname.getText().toString().trim();
		//String usermima = rmima.getText().toString().trim();
		//SQLiteDatabase mydb = helper.getWritableDatabase();
		//ContentValues values = new ContentValues();
		 //values.put("name", userName);
		 
		 //values.put("mima", usermima);
		//Context cont = null;
		//p = new GameView(cont);
	
		//mydb.insert("shuju", null, values);
		
		//if(userName.length()>0&&usermima.length()>0){
		//Toast.makeText(ZhuCe.this,"ע��ɹ�",1).show();
		//mydb.close();
		/*Intent in = new Intent();
		in.setClass(ZhuCe.this, MainActivity.class);
		startActivity(in);*/
		/*}else{
			Toast.makeText(ZhuCe.this,"ע��ʧ�ܣ�����Ϊ��",1).show();
		}*/
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
