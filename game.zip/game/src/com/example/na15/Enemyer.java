package com.example.na15;

import java.util.Random;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;

public class Enemyer  {
	public GameView gv;
	public int enx = 300;
	public int eny = 300;
	public int radius = 5;
	//public Bitmap enemyerMap;
	public Random r;
    public Enemyer(Context context,GameView gv){
    	this.gv = gv;
    	r = new Random();
    	enx=r.nextInt(gv.width);
    	eny=r.nextInt(gv.height);
	
}
public void drawEnemy(Canvas canvas,Paint p){
	
	canvas.drawCircle(enx, eny, radius, p);
}
}
