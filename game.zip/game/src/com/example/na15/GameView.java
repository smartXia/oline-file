package com.example.na15;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.widget.Toast;

public class GameView extends SurfaceView implements Callback{
    ArrayList<Enemyer> enList;
	Player p;
	SurfaceHolder myHolder;
	Canvas c;
	boolean isRunning = true;
	int width;
	int height;
	Context cont;
	int a,b,cc,d;
	public GameView(Context context) {
		super(context);
		myHolder = getHolder();
		myHolder.addCallback(this);
		cont=context;
		enList= new ArrayList<Enemyer>();
		
	}

	@Override
	public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
		// TODO �Զ����ɵķ������
		
	}

	@Override
	public void surfaceCreated(SurfaceHolder arg0) {
		// TODO �Զ����ɵķ������
		width=getWidth();
		height=getHeight();
		p = new Player(cont);
		for(int i =0;i<200;i++){
			Enemyer en = new Enemyer(cont,this);
			enList.add(en);
		}
		new DrawThread().start();
		
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder arg0) {
		// TODO �Զ����ɵķ������
		isRunning = false;
	}
	public void drawGameview(Canvas canvas){
		canvas = myHolder.lockCanvas();
		canvas.drawRGB(137,137,137);
		Paint paint=new Paint();
		paint.setColor(Color.YELLOW);
		Paint paint1=new Paint();
		paint1.setColor(Color.RED);
		Paint paint2=new Paint();
		paint2.setColor(Color.rgb(85, 85, 85));
		Paint paint6=new Paint();
		paint6.setColor(Color.rgb(175,215,136));
		Paint paint3=new Paint();
		paint3.setColor(Color.BLUE);
		Paint paint4=new Paint();
		paint4.setColor(Color.GREEN);
		Paint paint5=new Paint();
		paint5.setColor(Color.WHITE);
		paint5.setTextSize(40);
		paint1.setTextSize(40);
		paint.setAntiAlias(true);
		//canvas.drawText("������Ϸ", 100, 100, paint1);
		//����
		for(a=0;a<canvas.getWidth();a+=canvas.getWidth()/19){
			for(b=0;b<canvas.getHeight();b+=canvas.getHeight()/29){
			cc=a+canvas.getWidth()/20;
			d=b+canvas.getHeight()/30;
			canvas.drawRect(a,b,cc,d,paint2);
			//canvas.drawRoundRect(new RectF(a,b,cc,d),5,5,paint2);
			
			}}
		for(int i = 0;i<enList.size();i++){
			Enemyer e= enList.get(i);
			e.drawEnemy(canvas, paint6);
			//canvas.drawCircle(values.player_X,values.player_Y,values.bma,paint4);
		}
		
		p.drawPlayer(canvas ,paint);
		canvas.drawRect(20,20,200,70,paint4);
		canvas.drawText("�˳���Ϸ",30, 60, paint5);
		
		
		//canvas.drawT
		
		myHolder.unlockCanvasAndPost(canvas);
	}
	
	
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		p.onTouchEvent(event);
		if(event.getAction()==MotionEvent.ACTION_DOWN){
			int x = (int) event.getX();
			int y = (int) event.getY();
			if(x>30&&x<180&&y>30&&y<70){
				Builder b= new AlertDialog.Builder(cont);
				//b.setTitle("������Ϸ");
				b.setMessage("��Ҫ������Ϸ��");
				b.setPositiveButton("ȷ��",new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						
						ContentValues values = new ContentValues();
						values.put("play_X", p.player_X);
						values.put("play_Y", p.player_Y);
						values.put("bma", p.bma);
					    MySQLiteHelper helper = new MySQLiteHelper(cont,"MYDATABASE.db");
					    SQLiteDatabase mydb = helper.getWritableDatabase();
					    mydb.insert("shuju", null, values);
					    
					    	
                        //Toast.makeText(cont,a4,1).show();
					    //mydb.i
					    //cursor.close();
					    mydb.close();
						
						/*
						String enInfo = "";
						for(int i=0;i<enList.size();i++)
						{
							Enemyer e = enList.get(i);
							enInfo = enInfo + e.enx+","+e.eny+","+e.radius+";";
						}*/
						
						
						
					}
				});
				b.setNegativeButton("ȡ��", null);
				b.create();
				b.show();
				
				
			}
		}
		if(event.getAction()==MotionEvent.ACTION_MOVE){
			for(int i = 0;i<enList.size();i++){
				Enemyer e = enList.get(i);
				if(p.isConnectEn(e)){
					enList.remove(e);
				}
				
			}
		}
		return true;
	}



	class DrawThread extends Thread{

		@Override
		public void run() {
			while(isRunning){
				try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			drawGameview(c);
			}
		}
		
		
		
	}

}
