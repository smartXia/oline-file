package com.example.na15;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;


public class MySQLiteHelper extends SQLiteOpenHelper{

	public MySQLiteHelper(Context context, String name, CursorFactory factory,
			int version) {
		super(context, name, factory, version);
		// TODO �Զ����ɵĹ��캯�����
	}
	public MySQLiteHelper(Context context, String name) {
		this(context, name, null, 1);
		// TODO �Զ����ɵĹ��캯�����
	}
	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO �Զ����ɵķ������
		String sql ="create table if not exists shuju (" +
				"uid integer primary key autoincrement, " +
				"play_X integer ," +
				
				"play_Y integer ," +
						"bma integer)";
		
		
		db.execSQL(sql);
		
	}

	@Override
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
		// TODO �Զ����ɵķ������
		
	}

}
