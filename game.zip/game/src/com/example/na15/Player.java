package com.example.na15;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;

public class Player {
	
	public boolean isClicked = false;
	public int player_X=200;
	public int player_Y=200;
	public int bma = 15;
	
	public Player(Context context){
		
	}
	protected void drawPlayer(Canvas canvas,Paint p) {
		/*   Context cont = null;
		MySQLiteHelper helper = new MySQLiteHelper(cont,"MYDATABASE.db");
	    SQLiteDatabase mydb = helper.getReadableDatabase();
		Cursor cursor =mydb.rawQuery("select * from shuju", null);
	    while (cursor.moveToNext()) {
	    	   //int a1 = cursor.getInt(0); //��ȡ��һ�е�ֵ,��һ�е�������0��ʼ
	    	   player_X = cursor.getInt(1);//��ȡ�ڶ��е�ֵ
	    	   player_Y = cursor.getInt(2);//��ȡ�����е�ֵ
	    	   bma = cursor.getInt(3);
	    	}*/
		canvas.drawCircle(player_X,player_Y,bma,p);
		
	}
	
	public void onTouchEvent(MotionEvent event) {
		switch(event.getAction()){
		case MotionEvent.ACTION_DOWN:
			int x = (int) event.getX();
			int y = (int) event.getY();
			if(Math.abs((player_X-x)*(player_Y-y))>bma*bma){
				isClicked = true;
				}
			
		break;
		case MotionEvent.ACTION_MOVE:
			if(isClicked){
				player_X = (int) event.getX();
				player_Y = (int) event.getY();
			}
		break;
		case MotionEvent.ACTION_UP:
			isClicked = false;
		break;
		}
			}
	public boolean isConnectEn(Enemyer en){
		boolean result = false;
		if((en.enx-player_X)*(en.enx-player_X)+(en.eny-player_Y)*(en.eny-player_Y)<bma*bma){
			result=true;
			
			bma = bma+1;
		}
		return result;
	}
		
}
